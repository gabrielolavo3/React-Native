import React, { useState } from 'react'
import { View, Text, TextInput, TouchableOpacity } from 'react-native'
import { styles } from './style'

export function Formulario() {
    const [nome, setNome] = useState("")
    const [notaNumber, setNotaNumber] = useState("")
    const [notaNumber2, setNotaNumber2] = useState("")
    const [notaNumber3, setNotaNumber3] = useState("")    
    const [falta, setFalta] = useState("")
    
    function mediaFinal() {
        const media = (parseFloat(notaNumber) + parseFloat(notaNumber2) + parseFloat(notaNumber3)) / 3;
        const quantFalta = parseInt(falta) 
    
        if(media >= 7 && quantFalta <= 75) {
            alert(`${nome}, você foi aprovado(a)`)
        }
        else if (media >= 7 && quantFalta > 75) {
            alert(`${nome}, você foi reprovado(a) por frequência`)
        } 
        else {
            alert(`${nome}, você foi reprovado(a) por nota`)
        }
    }

    return (
        <View style = {styles.formContainer}>
            <View style = {styles.form}>
                <Text style = {styles.formLabel}>Nome do Estudante</Text>
                <TextInput
                    style = {styles.input} 
                    placeholder='Fulano de Tal' 
                    keyboardType='default'
                    value={nome} onChangeText={setNome}
                />
                <Text style = {styles.formLabel}>Primeira nota</Text>
                <TextInput 
                    style = {styles.input} 
                    placeholder='1.5' 
                    keyboardType='numeric'
                    value={notaNumber} onChangeText={setNotaNumber}
                />
                <Text style = {styles.formLabel}>Segunda nota</Text>
                <TextInput 
                    style = {styles.input} 
                    placeholder='7.8' 
                    keyboardType='numeric'
                    value={notaNumber2} onChangeText={setNotaNumber2}                    
                />
                <Text style = {styles.formLabel}>Terceira nota</Text>
                <TextInput
                    style = {styles.input} 
                    placeholder='10' 
                    keyboardType='numeric'
                    value={notaNumber3} onChangeText={setNotaNumber3}
                />
                <Text style = {styles.formLabel}>Quantidade de presença</Text>
                <TextInput
                    style = {styles.input} 
                    placeholder='97' 
                    keyboardType='numeric'
                    value={falta} onChangeText={setFalta}
                />
                <TouchableOpacity 
                    style = {styles.btnCalcular} activeOpacity={0.7}
                    onPress={mediaFinal}
                >
                    <Text style = {styles.textButton}>Calcular</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}