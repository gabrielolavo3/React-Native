import React from 'react'
import { View, Text } from 'react-native'
import { styles } from './style'

export function Titulo() {
    return (
        <View style = {styles.containerText}>
            <Text style = {styles.nomeText}>SCHOOL REPORT</Text>
        </View>
    )
}