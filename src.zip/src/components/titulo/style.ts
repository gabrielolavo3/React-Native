import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    containerText: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: 10,
    },

    nomeText: {
        color: 'white',
        fontSize: 24,
        fontWeight: 'bold'
    }
})