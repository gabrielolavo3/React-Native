import { View, StyleSheet } from "react-native";
import { Titulo } from "../components/titulo";
import { Formulario } from "../components/titulo/formulario";

export default function Index() {
  return (
    <View style = {styles.container}>
      <Titulo/>
      <Formulario/>
    </View>
  );
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A4F71',
    paddingTop: 80
  }
})